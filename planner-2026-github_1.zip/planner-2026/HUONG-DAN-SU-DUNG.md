# Hướng dẫn sử dụng Planner 2026

Ứng dụng có **2 phân vùng**, chuyển qua lại bằng nút **Planner / Tài chính** trên thanh trên cùng (hoặc bấm tiêu đề nhóm trong menu bên trái):

| Phân vùng | Gồm các trang |
|---|---|
| **Planner · Bộ 4 Sheets** | Tổng quan · 01 Mục tiêu · 02 Thói quen · 03 Kế hoạch tuần · 04 Toàn năm |
| **Tài chính** (Smart Financial & Fan Tracker) | A. Tổng quan · B. Sổ giao dịch · C. Ngân sách · D. Khoản nợ · E. Tiết kiệm · F. Hóa đơn định kỳ |

Mọi thay đổi **tự lưu ngay** trên máy (localStorage). Khi đã deploy lên Vercel có cơ sở dữ liệu, dữ liệu còn **tự đồng bộ** giữa các thiết bị (xem README).

---

## 0. Mở ứng dụng

| Cách | Làm thế nào | Lưu dữ liệu |
|---|---|---|
| Nhanh nhất | Nhấp đúp `Planner-2026-standalone.html` (bản 1 file) | Chỉ trên trình duyệt của máy đó |
| Từ mã nguồn | Nhấp đúp `public/index.html` | Chỉ trên máy đó |
| Chạy thử có API | `npm install` rồi `npm run dev` → mở http://localhost:3000 | Trên máy (thêm `.env.local` để đồng bộ) |
| Dùng mọi nơi | Deploy lên Vercel + Upstash Redis (README mục 1–3) | Đồng bộ mọi thiết bị |

**Lần đầu mở:** bấm **Tải dữ liệu mẫu** ở menu trái (hoặc trên thông báo chào mừng) để xem ứng dụng khi đã có dữ liệu. Khi muốn dùng thật, bấm **Xóa sạch dữ liệu** rồi nhập dữ liệu của bạn.

> Trình duyệt nên dùng: Chrome, Edge, Safari, Firefox bản mới. Đừng mở bằng chế độ ẩn danh nếu muốn giữ dữ liệu lâu dài.

---

## 1. Thao tác chung

- **Sửa trực tiếp:** mọi chữ, số, ngày, danh mục đều bấm vào là sửa được, không có nút “Lưu”. Biểu đồ và thẻ số liệu cập nhật ngay.
- **Nhập số tiền kiểu tắt** (dùng được ở mọi ô tiền):

  | Gõ | Hiểu là |
  |---|---|
  | `50k` | 50.000 ₫ |
  | `1,5tr` hoặc `1.5tr` | 1.500.000 ₫ |
  | `2 triệu` | 2.000.000 ₫ |
  | `250.000` hoặc `250000` | 250.000 ₫ |

  Rời ô (hoặc nhấn `Enter`) là số tự định dạng lại `1.500.000`.
- **Chọn kỳ xem** (Tổng quan, Sổ giao dịch, Ngân sách, Hóa đơn): dùng nút `‹ Tháng 9/2026 ›` hoặc chọn “Tất cả thời gian”. Kỳ đang xem là lựa chọn riêng của từng thiết bị.
- **Xoá nhầm?** Hầu hết thao tác xoá có nút **Hoàn tác** trên thông báo ở góc dưới (vài giây).
- **Tìm kiếm** (phím `/`): tìm được mục tiêu, công việc, sự kiện, giao dịch, tên quỹ, khoản nợ, hoá đơn. Chọn kết quả → nhảy tới đúng ô đó.
- **Chuông thông báo** nhắc: hoá đơn sắp đến hạn / quá hạn, khoản nợ sắp đáo hạn, quỹ fan sắp đến hạn chót, danh mục chi sắp chạm / vượt ngân sách, mục tiêu & sự kiện sắp tới.
- **Menu trái** tự ẩn — rê chuột vào mép trái để mở; nút **Ghim menu** ở cuối menu để giữ cố định. Trên điện thoại bấm nút ☰.
- **Thẻ ở cuối menu** đổi theo phân vùng: Planner hiện tiến độ chu kỳ 90 ngày; Tài chính hiện Số dư thực tế, nợ, quỹ, hoá đơn và nút **Giao dịch mới**.

---

## 2. Phân vùng Planner (Bộ 4 Sheets)

Luồng làm việc **MỤC TIÊU → HÀNH ĐỘNG → KẾT QUẢ** trong 90 ngày:

1. **Mục tiêu (Goal Planner):** 6 thẻ mục tiêu — tên, ảnh Vision Board, lĩnh vực, hạn chót, 3 câu tự vấn, các bước hành động có checkbox, phần thưởng. Tiến độ theo 5 lĩnh vực có **sparkline 30 ngày** và biểu đồ donut.
2. **Thói quen (Habit Tracker):** lưới tháng, bấm ô để đánh dấu; % hoàn thành theo ngày / tuần / tháng tự tính.
3. **Kế hoạch tuần:** mỗi ngày có biết ơn, ưu tiên số 1, việc cần làm và **Time Blocking 07:00–22:00**.
4. **Toàn năm:** lịch 12 tháng, thêm sự kiện, mục tiêu từng tháng.
5. **Tổng quan:** gom tất cả lại, kèm thẻ “Tài chính tháng này” (thu, chi, nợ, quỹ, hoá đơn, số dư).

---

## 3. Phân vùng Tài chính

### Cách ứng dụng tính tiền (nên đọc trước)

```
Số dư thực tế = Số dư đầu kỳ
              + Tổng các khoản Thu
              − Tổng các khoản Chi   (gồm cả “Trả nợ” và “Hóa đơn”)
              − Tiền đã nạp vào quỹ  (chỉ phần “trừ vào số dư”)
              + Tiền rút từ quỹ về ví
```

- **Sổ giao dịch là nguồn sự thật duy nhất.** Trả nợ và trả hoá đơn đều tạo một giao dịch Chi có gắn nhãn liên kết (🔗 tên khoản nợ / hoá đơn).
  → Xoá giao dịch đó trong Sổ giao dịch thì khoản nợ tự tăng lại số còn nợ, hoá đơn tự trở về “Chưa trả”.
- **Nạp quỹ** không phải là chi tiêu: tiền chỉ chuyển từ ví sang quỹ, nên **Tổng chi tiêu không đổi** nhưng **Số dư thực tế giảm**.
- **Tài sản ròng** = Số dư thực tế + Tổng quỹ − Nợ còn lại.

### A. Tổng quan tài chính

5 thẻ số liệu theo kỳ đang xem, mỗi thẻ có sparkline 6 tháng:

| Thẻ | Ý nghĩa |
|---|---|
| **Tổng thu nhập** | Tổng các khoản Thu trong kỳ, kèm % tăng/giảm so với tháng trước |
| **Tổng chi tiêu** | Tổng các khoản Chi trong kỳ, kèm chênh lệch thu − chi |
| **Số dư thực tế** | Tiền đang có trong ví/tài khoản (công thức ở trên). Ô **Đầu kỳ** ngay trên thẻ: bấm để nhập số tiền bạn có trước giao dịch đầu tiên |
| **Khoản nợ còn lại** | Tổng số còn phải trả của các khoản nợ chưa hoàn thành |
| **Quỹ tiết kiệm / Concert** | Tổng tiền đang có trong mọi quỹ, % đạt so với tổng mục tiêu |

Bên dưới có:

- biểu đồ **Dòng tiền 6 tháng** (cột thu/chi, đường số dư và quỹ);
- **Chi tiêu theo danh mục** (chuyển tròn ↔ cột bằng 2 nút nhỏ);
- tóm tắt **Quỹ fan** (nút **Nạp** nhanh), **Hóa đơn tháng** (tick đã trả ngay tại đây), **Khoản nợ đang trả** (nút **Trả bớt**), **Ngân sách tháng** và **Giao dịch gần đây**.

### B. Sổ giao dịch

**Thêm giao dịch** — khung trên cùng:

1. Chọn **Ngày** (mặc định hôm nay).
2. Gõ **Mô tả** (vd: *Vé phòng trà cuối tuần*).
3. Chọn **Loại**: Chi hoặc Thu.
4. Chọn **Danh mục**:

   | Loại | Danh mục |
   |---|---|
   | Thu | Lương, Thưởng |
   | Chi | Ăn uống, Mua sắm, Vé Concert/Phòng trà, Hóa đơn, Trả nợ |
   | Cả hai | Khác |

5. Gõ **Số tiền** (vd `650k`) → nhấn **Enter** hoặc nút **Thêm**.

> Ở mọi trang tài chính còn có nút **Giao dịch mới** (mở hộp thoại nhanh), cả trên thẻ cuối menu.

**Sửa / xoá:**

- Bấm vào ngày, mô tả, loại, danh mục hay số tiền của bất kỳ dòng nào để sửa; tổng ở thanh công cụ tự cập nhật.
- Đổi ngày sang tháng khác → giao dịch chuyển sang tháng đó (có thông báo).
- Nút 🗑 để xoá, có **Hoàn tác**.

**Lọc & xuất:**

- **Tất cả / Thu / Chi**, ô **Mọi danh mục** (lọc theo từng danh mục), ô **Tìm mô tả** (gõ không dấu cũng được: `phong tra`).
- Kết hợp với chọn tháng ở góc trên để lọc theo tháng.
- **Xuất CSV** xuất đúng danh sách đang lọc — mở bằng Excel vẫn giữ tiếng Việt.

### C. Ngân sách tháng & cảnh báo

1. Mở **Ngân sách**, chọn tháng.
2. Với mỗi danh mục chi, bấm vào ô **“đặt hạn mức”** và gõ số (vd `4tr`).
3. Thanh tiến độ và màu tự đổi:

   | Đã dùng | Màu | Ý nghĩa |
   |---|---|---|
   | dưới 80% | Xanh | An toàn |
   | 80% – 100% | **Vàng** | Sắp chạm hạn mức (“⚠ Sắp chạm hạn mức”) |
   | trên 100% | **Đỏ** | Đã vượt (“⚠ Vượt … ₫”) |

- **Gợi ý theo 3 tháng:** đặt hạn mức tất cả danh mục bằng mức chi trung bình 3 tháng trước (làm tròn lên); hoặc bấm **Dùng mức này** ở từng danh mục.
- 4 thẻ phía trên: Tổng hạn mức, Đã chi, Còn lại, số danh mục đang vượt / sắp chạm. Biểu đồ **Ngân sách vs thực chi** so sánh từng danh mục.
- Hạn mức áp dụng cho **mọi tháng** (đặt một lần, dùng mãi); tháng nào xem riêng tháng đó.
- Chuông thông báo nhắc khi **tháng hiện tại** có danh mục vàng/đỏ.

### D. Khoản vay & khoản nợ

**Thêm:** nút **Thêm khoản nợ** → nhập:

- Tên (vd *Trả góp điện thoại*), Chủ nợ/ghi chú;
- **Tổng số tiền**, **Đã trả trước đó** (số đã trả trước khi bắt đầu theo dõi — không trừ vào số dư);
- **Trả mỗi tháng** (khoản trả góp; bỏ trống nếu trả một lần);
- **Ngày đáo hạn** (hạn cuối). Với khoản trả góp, **ngày** của hạn này cũng là hạn trả hằng tháng — vd đáo hạn 08/03/2027 thì tháng nào cũng phải trả trước ngày 08.

**Bảng** gồm Tên | Tổng số tiền | Đã trả (thanh %) | Còn lại | **Cần trả tháng này** | Ngày đáo hạn (chip “Còn 5 ngày”, “Quá hạn 3 ngày”…) | Thao tác.

**Số nợ cần trả trong tháng** — thẻ “Cần trả tháng …” ở đầu trang và cột “Cần trả tháng này” của từng khoản:

| Khoản nợ | Cần trả tháng này |
|---|---|
| Ngày đáo hạn nằm trong tháng này (hoặc đã quá hạn) | Toàn bộ phần còn lại |
| Có “Trả mỗi tháng”, đáo hạn ở tháng sau | Số trả mỗi tháng (không vượt phần còn lại) |
| Không có “Trả mỗi tháng”, đáo hạn ở tháng sau | Không có kỳ trả tháng này |

- Thẻ hiện tổng phải trả, **đã trả** và **còn** bao nhiêu trong tháng (thanh tiến độ).
- Từng khoản có chip “Còn 1,5tr · hạn 08/10” hoặc “✓ Đã trả đủ”.
- Sửa ô **Mỗi tháng** ngay trên dòng là số liệu cập nhật luôn.
- Con số này còn hiện ở thẻ “Khoản nợ còn lại” (Tổng quan tài chính), thẻ cuối menu và thẻ Tài chính ở trang Tổng quan Planner.

**Thao tác:**

- **Ghi nhận trả bớt:** ô số tiền điền sẵn số còn phải trả tháng này; nhập ngày trả → ứng dụng tạo giao dịch *Chi · Trả nợ* trong Sổ giao dịch, trừ vào Số dư thực tế, cộng vào “Đã trả”. Không cho nhập quá số còn lại.
- **Hoàn thành:** nếu còn nợ, chọn **Ghi nhận trả nốt** (tạo giao dịch tất toán) hoặc **Chỉ đánh dấu hoàn thành** (đã trả ngoài ứng dụng / được xoá nợ). Khoản trả đủ tiền cũng tự chuyển sang Hoàn thành.
- **Mở lại** khoản đã hoàn thành; sửa trực tiếp tên, chủ nợ, tổng tiền, số trả mỗi tháng, ngày đáo hạn.
- **Lịch sử trả (n)** — bấm để xem từng lần trả.
- Biểu đồ **Tiến độ trả nợ** (đã trả / còn lại) và **Số tiền trả nợ 6 tháng gần nhất**.
- Chuông nhắc khi khoản nợ còn ≤ 7 ngày đến hạn hoặc đã quá hạn, và khi kỳ trả góp tháng này sắp tới hạn mà chưa trả đủ.

### E. Tiết kiệm (quỹ tiết kiệm & mục tiêu Concert / Phòng trà Idol)

**Tạo quỹ:** nút **Tạo quỹ mới** →

- **Tên quỹ** (vd *Quỹ Concert [tên nghệ sĩ] 2026*, *Quỹ đi Phòng trà Idol*);
- **Loại**: Concert · Phòng trà · Album / Merch · Khẩn cấp · Du lịch / Fanmeet · Tiết kiệm khác;
- **Mục tiêu**, **Hạn chót**, ghi chú;
- **Số tiền đã có sẵn** — được tính vào quỹ nhưng **không** trừ vào số dư.

**Mỗi thẻ quỹ hiển thị:**

- Đã tích luỹ / Mục tiêu (bấm để sửa);
- vòng tròn % và thanh tiến độ;
- **Còn thiếu**, còn bao nhiêu ngày;
- **Gợi ý cần nạp mỗi tháng / mỗi tuần** để kịp hạn chót.

**Nạp thêm tiền vào quỹ:**

1. Bấm **Nạp thêm tiền** (ô số tiền đã điền sẵn mức gợi ý hằng tháng).
2. Giữ tick **Trừ vào số dư thực tế** → tiền chuyển từ ví sang quỹ (Số dư thực tế giảm, Quỹ tăng).
3. Bỏ tick nếu tiền đến từ nguồn ngoài (quà, lì xì…) → chỉ cộng vào quỹ.
4. Khi quỹ đạt mục tiêu: hiệu ứng chúc mừng 🎉 và viền xanh “Đã đạt mục tiêu — sẵn sàng săn vé!”.

**Rút / chi từ quỹ:**

- **Dùng để chi tiêu** (vd mua vé concert): trừ tiền trong quỹ và ghi một giao dịch Chi (chọn danh mục, vd *Vé Concert/Phòng trà*) — Số dư thực tế **không đổi** vì tiền lấy từ quỹ.
- **Rút về số dư thực tế:** tiền quay lại ví, không ghi chi tiêu.

**Khác:**

- 3 lần nạp/rút gần nhất hiện ngay trên thẻ, “Xem thêm” để xem hết.
- Xoá quỹ thì phần đã nạp từ số dư được cộng trả lại Số dư thực tế.
- Biểu đồ **Tiến độ các quỹ** (đã tích luỹ / còn thiếu).
- Thẻ **Quỹ Fan** tách riêng tổng các quỹ concert, phòng trà, merch, fanmeet.

### F. Hóa đơn định kỳ

**Thêm:** nút **Thêm hoá đơn** → Tên (vd *Tiền nhà*, *Điện*, *Nước*, *Internet*), Loại, **Hạn trả** (ngày 1–31 hằng tháng), Số tiền mỗi tháng.

**Hằng tháng:**

- Chọn tháng ở góc trên.
- Tick ô tròn **Đã trả** → ứng dụng ghi giao dịch *Chi · Hóa đơn* đúng số tiền của hoá đơn vào Sổ giao dịch.
- **Bỏ tick** → giao dịch đó bị xoá, hoá đơn về “Chưa trả” (có Hoàn tác).
- Nếu số thực trả khác (vd tiền điện tháng này 712.000 ₫), sửa số tiền của giao dịch đó trong Sổ giao dịch; hoá đơn vẫn là “Đã trả” và tổng “Đã trả” dùng số thực.

**Trạng thái mỗi dòng:**

| Trạng thái | Khi nào |
|---|---|
| ✓ Đã trả dd/mm | Đã tick trong tháng đang xem |
| Còn n ngày (vàng) | Còn ≤ 3 ngày tới hạn |
| Quá hạn n ngày (đỏ) | Qua hạn mà chưa tick |
| Chưa trả · còn n ngày | Còn xa hạn |

- Hạn ngày 31 ở tháng ít ngày hơn tự hiểu là ngày cuối tháng.
- Sửa trực tiếp tên, loại, ngày hạn, số tiền (số mới áp dụng cho các lần tick sau).
- Thẻ tóm tắt: Tổng hoá đơn tháng · Đã trả · Còn phải trả · Quá hạn. Chuông nhắc hoá đơn sắp/quá hạn trong tháng hiện tại.

---

## 4. Ví dụ một tháng sử dụng

1. **Ngày 1 – nhận lương:** Sổ giao dịch → *Lương tháng 10* · Thu · Lương · `18tr`.
2. **Ngay sau đó – trả nợ & hoá đơn:**
   - Khoản nợ → xem thẻ **Cần trả tháng …** → *Trả góp điện thoại* → **Ghi nhận trả bớt** (số tiền đã điền sẵn).
   - Hóa đơn định kỳ → tick **Tiền nhà**.
3. **Để dành cho Idol:**
   - Tiết kiệm → *Quỹ Concert* → **Nạp thêm tiền** (dùng số gợi ý).
   - *Quỹ Phòng trà* → nạp `500k`.
4. **Hằng ngày:** thêm chi tiêu ăn uống, mua sắm… (gõ `45k`, Enter là xong).
5. **Giữa tháng:** xem **Ngân sách** — danh mục nào vàng thì tiết chế; tick tiếp hoá đơn điện, nước, internet khi trả.
6. **Khi mở bán vé:** *Quỹ Concert* → **Rút / chi** → *Dùng để chi tiêu* → danh mục *Vé Concert/Phòng trà*.
7. **Cuối tháng:** xem **Tổng quan** để biết thu − chi, số dư thực tế, tài sản ròng. Bấm **Xuất CSV** nếu cần lưu trữ.

---

## 5. Dữ liệu, sao lưu & đồng bộ

| Nút (menu trái) | Tác dụng |
|---|---|
| **Tải dữ liệu mẫu** | Thay toàn bộ dữ liệu bằng bộ mẫu (Planner + 6 tháng tài chính, 4 khoản nợ, 4 quỹ fan, 6 hoá đơn) |
| **Xóa sạch dữ liệu** | Xoá mọi dữ liệu Planner & tài chính, giữ tên hồ sơ |
| **Sao lưu (JSON)** | Tải về một tệp chứa toàn bộ dữ liệu |
| **Khôi phục từ JSON** | Nạp lại tệp sao lưu |
| **Lịch sử đồng bộ** | (khi có đồng bộ) xem & khôi phục 30 phiên bản gần nhất trên máy chủ |

- Nút trạng thái cạnh chuông: **Đã đồng bộ** / **Đang lưu…** / **Mất kết nối · đã lưu trên máy** / **Chỉ lưu trên máy này**. Bấm vào để đồng bộ ngay, xem lịch sử, đặt tên thiết bị.
- Tháng đang xem, bộ lọc, chế độ menu là lựa chọn riêng từng thiết bị; còn giao dịch, ngân sách, nợ, quỹ, hoá đơn được đồng bộ.
- Dữ liệu từ phiên bản trước (danh mục cũ *Nhà cửa, Giải trí, Đầu tư*) được tự chuyển sang *Hóa đơn, Mua sắm, Khác*.

---

## 6. Câu hỏi thường gặp

**Số dư thực tế bị âm / không khớp ví thật?**
Bấm vào ô **Đầu kỳ** trên thẻ Số dư thực tế và nhập số tiền bạn có *trước* giao dịch đầu tiên trong sổ.

**Nạp quỹ mà Tổng chi tiêu không tăng?**
Đúng vậy: nạp quỹ là chuyển tiền sang “ống heo”, không phải tiêu. Khi thật sự mua vé, dùng **Rút / chi → Dùng để chi tiêu** để ghi khoản chi.

**Lỡ tick nhầm hoá đơn / ghi nhầm khoản trả nợ?**
Bỏ tick hoá đơn, hoặc xoá giao dịch “Trả nợ” tương ứng trong Sổ giao dịch — số liệu tự cập nhật lại.

**Hoá đơn tháng này số tiền khác mọi tháng?**
Tick đã trả rồi sửa số tiền của giao dịch vừa tạo trong Sổ giao dịch.

**Prompt yêu cầu “Tailwind qua CDN” — sao dự án dùng file `tailwind.css`?**
Tailwind CDN (Play CDN) chỉ dành cho thử nghiệm: phải tải script lớn và biên dịch CSS mỗi lần mở trang, không chạy khi mất mạng, và bị chặn bởi chính sách bảo mật (CSP) của bản deploy.
Dự án vẫn viết giao diện bằng class Tailwind y hệt, chỉ là biên dịch sẵn bằng `npm run build` thành `public/css/tailwind.css`. Nhờ vậy trang mở nhanh hơn, chạy cả khi offline và khi nhấp đúp file.
Nếu vẫn muốn dùng CDN để thử: thêm `<script src="https://cdn.tailwindcss.com"></script>` vào `<head>` của `index.html` (khi deploy cần nới CSP trong `vercel.json`).

**Muốn đổi tên/màu danh mục?**
Sửa mảng `FIN_CATS`, `FUND_KINDS`, `BILL_KINDS` ở đầu `public/js/core.js`, rồi chạy `npm run build`.
