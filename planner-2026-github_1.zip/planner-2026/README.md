# Planner 2026 — Bộ 4 Sheets & Smart Financial / Fan Tracker

Ứng dụng web một trang gồm **2 phân vùng**, chuyển nhanh bằng nút **Planner / Tài chính** trên thanh trên cùng:

1. **Planner (Bộ 4 Sheets 2026)** — luồng MỤC TIÊU → HÀNH ĐỘNG → KẾT QUẢ trong 90 ngày:
   Tổng quan · Goal Planner (5 lĩnh vực có sparkline 30 ngày + donut) · Habit Tracker · Weekly Planner · Year at a Glance.
2. **Tài chính (Smart Financial & Fan Tracker)**:
   - **A. Tổng quan** — Tổng thu nhập · Tổng chi tiêu · Số dư thực tế · Khoản nợ còn lại · Quỹ tiết kiệm/Concert, dòng tiền 6 tháng, chi tiêu theo danh mục.
   - **B. Sổ giao dịch** — Ngày · Mô tả · Thu/Chi · Danh mục (Lương, Thưởng, Ăn uống, Mua sắm, Vé Concert/Phòng trà, Hóa đơn, Trả nợ, Khác) · Số tiền; lọc theo tháng / danh mục, xuất CSV.
   - **C. Ngân sách tháng** — hạn mức theo danh mục, % đã dùng, vàng khi đạt 80%, đỏ khi vượt 100%.
   - **D. Khoản nợ** — tổng, đã trả, còn lại, **số nợ cần trả trong tháng**, ngày đáo hạn, “Ghi nhận trả bớt”, Hoàn thành.
   - **E. Tiết kiệm** — Quỹ Concert, Phòng trà, Album/Merch, Khẩn cấp…: mục tiêu, đã tích luỹ, % và gợi ý nạp mỗi tháng, “Nạp thêm tiền vào quỹ”.
   - **F. Hóa đơn định kỳ** — nhà, điện, nước, internet… tick Đã trả / Chưa trả theo tháng, nhắc hạn.

📘 **Hướng dẫn sử dụng chi tiết: [HUONG-DAN-SU-DUNG.md](HUONG-DAN-SU-DUNG.md)**

- **Đồng bộ mọi thiết bị**: mở web ở laptop, điện thoại hay máy khác đều thấy cùng một dữ liệu.
- **Chạy được cả khi mất mạng**: thay đổi lưu ngay trên máy, có mạng lại thì tự đồng bộ.
- **Lịch sử 30 phiên bản** trên máy chủ để khôi phục khi lỡ tay.
- Menu bên trái tự ẩn, trượt ra khi rê chuột vào mép trái (có thể ghim lại).

Kiến trúc: trang tĩnh (`public/`) + 1 Vercel Function (`api/state.js`) lưu dữ liệu vào **Upstash Redis** (gói miễn phí, cài từ Vercel Marketplace).

---

## 1. Đưa code lên GitHub

Tạo repository trống trên GitHub (ví dụ `planner-2026`, **không** tick “Add a README”), rồi trong thư mục dự án:

```bash
git init
git add .
git commit -m "Planner 2026: bộ 4 sheets + tài chính & fan tracker"
git branch -M main
git remote add origin https://github.com/<ten-tai-khoan>/planner-2026.git
git push -u origin main
```

Về sau mỗi lần sửa: `git add . && git commit -m "mô tả" && git push` — Vercel tự deploy lại.

## 2. Deploy lên Vercel

1. Đăng nhập https://vercel.com bằng tài khoản GitHub.
2. **Add New… → Project** → chọn repo `planner-2026` → **Import**.
3. Để nguyên cấu hình (đã khai báo trong `vercel.json`) → **Deploy**.

Lúc này web đã chạy nhưng nút trạng thái hiện **“Chỉ lưu trên máy này”** vì chưa có cơ sở dữ liệu.

## 3. Bật đồng bộ (thêm cơ sở dữ liệu — làm 1 lần)

1. Mở project trên Vercel → mục **Storage** → **Create Database** (hoặc **Connect Database**).
2. Chọn **Upstash for Redis** (Marketplace) → chọn gói **Free** → đặt tên (vd `planner-db`) → **Create**.
3. Ở bước kết nối, chọn project `planner-2026` (cả Production / Preview / Development) → **Connect**.
   Vercel tự thêm biến môi trường `KV_REST_API_URL` và `KV_REST_API_TOKEN`.
4. Vào tab **Deployments** → bấm **⋯** ở bản mới nhất → **Redeploy** (biến môi trường chỉ áp dụng cho bản deploy mới).
5. Mở lại web: nút trạng thái trên cùng chuyển thành **“Đã đồng bộ”** là xong.

> Nếu bạn đã dùng thử trước đó, dữ liệu trên máy sẽ được đưa lên máy chủ ở lần mở đầu tiên.
> Thiết bị khác mở web sẽ tự nhận dữ liệu đó.

## 4. Đồng bộ hoạt động thế nào?

| Tình huống | App xử lý |
|---|---|
| Sửa bất kỳ ô nào | Lưu ngay trên máy → ~1,2 giây sau gửi lên máy chủ |
| Mở web / quay lại tab / có mạng lại / mỗi 30 giây | Lấy bản mới nhất từ máy chủ |
| Đang gõ dở khi có bản mới | Đợi bạn rời ô rồi mới cập nhật |
| Mất mạng | Hiện “Mất kết nối · đã lưu trên máy”, tự gửi khi có mạng |
| Sửa trên 2 máy cùng lúc (vd 1 máy offline) | Hỏi giữ bản nào; bản không chọn vẫn được cất vào Lịch sử |
| Lỡ tay xoá / ghi đè | Menu → **Lịch sử đồng bộ** → chọn phiên bản → Khôi phục |

- Bấm vào **nút trạng thái** (góc trên, cạnh chuông) để: đồng bộ ngay, xem lịch sử, đặt tên thiết bị.
- Lịch sử lưu tối đa 30 phiên bản, tự chụp tối đa 10 phút/lần; các thao tác lớn (tải mẫu, xoá sạch, khôi phục JSON) luôn chụp lại bản cũ trước.
- Tháng đang xem, tuần đang xem, chế độ menu… là lựa chọn riêng của từng thiết bị, không bị đồng bộ.
- Giới hạn khoảng 3,5 MB dữ liệu — ưu tiên dán URL ảnh thay vì tải ảnh lớn lên.

## 5. Tài chính — tóm tắt

- **Nhập số tiền kiểu tắt**: `50k` = 50.000 · `1,5tr` = 1.500.000 · `2 triệu` · `250.000` đều được.
- **Số dư thực tế** = Đầu kỳ + Σ thu − Σ chi − tiền nạp vào quỹ (từ số dư) + tiền rút từ quỹ về.
- **Trả nợ** (“Ghi nhận trả bớt”) và **tick hoá đơn đã trả** tự tạo giao dịch Chi có nhãn liên kết trong Sổ giao dịch;
  xoá giao dịch đó thì khoản nợ / hoá đơn tự cập nhật lại.
- **Nạp quỹ** chuyển tiền từ ví sang quỹ (không tính là chi tiêu); **Rút / chi** từ quỹ để mua vé sẽ ghi khoản chi tương ứng.
- **Chuông thông báo** nhắc hoá đơn sắp/quá hạn, nợ sắp đáo hạn, quỹ sắp đến hạn chót, danh mục sắp chạm / vượt ngân sách.
- Kỳ đang xem và bộ lọc là lựa chọn riêng của từng thiết bị; mọi dữ liệu tài chính được đồng bộ như phần Planner.

Chi tiết từng màn hình, ví dụ một tháng sử dụng và câu hỏi thường gặp: **[HUONG-DAN-SU-DUNG.md](HUONG-DAN-SU-DUNG.md)**.

> **Về “Tailwind qua CDN”:** giao diện vẫn viết bằng class Tailwind, nhưng được biên dịch sẵn (`npm run build` → `public/css/tailwind.css`)
> thay vì tải Play CDN mỗi lần mở trang — nhanh hơn, chạy được khi offline / nhấp đúp file và không vướng CSP khi deploy.

## 6. Lưu ý về quyền truy cập

Theo lựa chọn của bạn, web **không có mật khẩu**: ai có đường link đều xem và sửa được dữ liệu. Vài cách giảm rủi ro mà không thêm bước đăng nhập:

- Đặt tên project khó đoán (vd `planner-2026-dk7q`) vì link có dạng `https://<ten-project>.vercel.app`, và đừng chia sẻ link.
- Trang đã gắn `noindex` nên không bị Google và các công cụ tìm kiếm liệt kê.
- Có **Lịch sử đồng bộ** và **Sao lưu (JSON)** để khôi phục nếu dữ liệu bị ghi đè.

## 7. Chạy trên máy (tuỳ chọn)

```bash
npm install
npm run dev          # http://localhost:3000
```

- Không có biến môi trường → chạy chế độ “chỉ lưu trên máy”.
- Muốn đồng bộ khi chạy trên máy: `npm i -g vercel`, `vercel link`, `vercel env pull .env.local`, rồi `npm run dev`
  (dùng chung cơ sở dữ liệu với bản trên Vercel).
- Nhấp đúp `public/index.html` hoặc bản 1 file (`npm run bundle` → `dist/planner-2026.html`) cũng chạy được, nhưng chỉ lưu trên máy.
- Thêm class Tailwind mới vào HTML/JS thì chạy `npm run build` (hoặc `npm run watch`).

## API (`api/state.js`)

| Phương thức | Đường dẫn | Mô tả |
|---|---|---|
| GET | `/api/state` | Lấy dữ liệu `{ rev, updatedAt, device, state }` |
| GET | `/api/state?since=REV` | `{ changed: false }` nếu chưa có gì mới |
| PUT | `/api/state` | Ghi `{ baseRev, state, device }` → `{ rev }`, hoặc `409` kèm bản hiện tại nếu thiết bị khác vừa ghi |
| GET | `/api/state?history=1` | Danh sách 30 phiên bản gần nhất |
| POST | `/api/state?restore=N` | Khôi phục phiên bản thứ N |
| POST | `/api/state?archive=1` | Cất một bản vào lịch sử |

Ghi dữ liệu dùng Lua script chạy nguyên tử trong Redis (compare-and-set theo `rev`), nên hai thiết bị không thể vô tình ghi đè lên nhau.

## Cấu trúc thư mục

```
planner-2026/
├── api/state.js            Vercel Function: đồng bộ qua Upstash Redis
├── public/                 trang web (thư mục được deploy)
│   ├── index.html · favicon.svg
│   ├── css/style.css · css/tailwind.css (tự sinh bởi `npm run build`)
│   └── js/
│       ├── core.js         hằng số, tiện ích, Store (localStorage), UI, icon
│       ├── sync.js         đồng bộ: gửi/nhận, xung đột, lịch sử, trạng thái
│       ├── sample-data.js  dữ liệu mẫu
│       ├── goals.js · habits.js · weekly.js · year.js · dashboard.js   (Planner)
│       ├── finance.js      Tài chính: tổng quan, sổ giao dịch, ngân sách, nợ, quỹ fan, hoá đơn
│       ├── app.js          điều hướng, sửa trực tiếp, menu tự ẩn, tìm kiếm, sao lưu
│       └── vendor/chart.umd.js   Chart.js 4.4.1 (MIT)
├── scripts/dev-server.mjs  chạy thử trên máy (trang + API)
├── scripts/bundle.mjs      gộp thành 1 file HTML
├── src/tailwind.css · tailwind.config.js
├── HUONG-DAN-SU-DUNG.md    hướng dẫn sử dụng chi tiết (tiếng Việt)
├── vercel.json             cấu hình build + header bảo mật
└── package.json
```

## Phím tắt

`/` tìm kiếm · `Enter` xuống dòng kế tiếp trong danh sách · `Esc` đóng hộp thoại · `Tab` vào menu khi menu đang ẩn.

## Giấy phép bên thứ ba

Chart.js — MIT (`public/js/vendor/LICENSE-chartjs.md`) · Tailwind CSS — MIT
